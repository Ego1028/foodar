var x =3;
var y =7;
var z =x-7;
console.log("Result: "+z);
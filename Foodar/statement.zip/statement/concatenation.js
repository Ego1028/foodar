var firstName = "ruolin";
var lastName = "meng";
console.log(firstName+" "+lastName);
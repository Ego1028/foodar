var x=10;
if(x>5){
	console.log("the value of x is greater than 5");
}
